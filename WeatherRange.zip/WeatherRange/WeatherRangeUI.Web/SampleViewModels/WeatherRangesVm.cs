
using System;
using System.ComponentModel.DataAnnotations;
using WeatherRangeUI.BusinessObjects;

namespace WeatherRangeUI.Web.SampleViewModels
{
    public partial class WeatherRangesVm
    {
        #region member properties

        public virtual Int64? Id { get; set; }

        [Required(ErrorMessage = "Min Range Required!")]

        public virtual Int32? MinRange { get; set; }

        [Required(ErrorMessage = "Max Range Required!")]
        public virtual Int32? MaxRange { get; set; }

        [Required(ErrorMessage = "Adjective Required!")]
        public virtual string Adjective { get; set; }
        #endregion

        public WeatherRangesVm() { }

        public WeatherRangesVm(BOWeatherRanges boWeatherRanges)
        {
            Id = boWeatherRanges.Id;
            MinRange = boWeatherRanges.MinRange;
            MaxRange = boWeatherRanges.MaxRange;
            Adjective = boWeatherRanges.Adjective;
        }

        public BOWeatherRanges BOWeatherRanges()
        {
            var boWeatherRanges = new BOWeatherRanges()
            {
                Id = this.Id,
                MinRange = this.MinRange,
                MaxRange = this.MaxRange,
                Adjective = this.Adjective
            };
            return boWeatherRanges;
        }
    }
}
