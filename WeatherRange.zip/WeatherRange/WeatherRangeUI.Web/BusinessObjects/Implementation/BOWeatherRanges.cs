 
using System;
using System.Collections.Generic;
using WeatherRangeUI.DataObjects;
using WeatherRangeUI.DataObjects.Interfaces;
using WeatherRangeUI.BusinessObjects.Interfaces;

namespace WeatherRangeUI.BusinessObjects
{
	///<Summary>
	///Class definition
	///This is the definition of the class BOWeatherRanges.
	///</Summary>
	public partial class BOWeatherRanges : WeatherRangeDBConnection_BaseBusiness, IQueryableCollection, IUnitOfWorkEntity
	{
		#region member variables
		protected Int64? _id;
		protected Int32? _minRange;
		protected Int32? _maxRange;
		protected string _adjective;
		protected bool _isDirty = false;
		/*collection member objects*******************/
		/*********************************************/
		#endregion

		#region class methods
		///<Summary>
		///Constructor
		///This is the default constructor
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///
		///</parameters>
		public BOWeatherRanges()
		{
		}

		///<Summary>
		///Constructor
		///Constructor using primary key(s)
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///Int64 id
		///</parameters>
		public BOWeatherRanges(Int64 id)
		{
			try
			{
				DAOWeatherRanges daoWeatherRanges = DAOWeatherRanges.SelectOne(id);
				_id = daoWeatherRanges.Id;
				_minRange = daoWeatherRanges.MinRange;
				_maxRange = daoWeatherRanges.MaxRange;
				_adjective = daoWeatherRanges.Adjective;
			}
			catch
			{
				throw;
			}
		}

		///<Summary>
		///Constructor
		///This constructor initializes the business object from its respective data object
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///DAOWeatherRanges
		///</parameters>
		protected internal BOWeatherRanges(DAOWeatherRanges daoWeatherRanges)
		{
			try
			{
				_id = daoWeatherRanges.Id;
				_minRange = daoWeatherRanges.MinRange;
				_maxRange = daoWeatherRanges.MaxRange;
				_adjective = daoWeatherRanges.Adjective;
			}
			catch
			{
				throw;
			}
		}

		///<Summary>
		///SaveNew
		///This method persists a new WeatherRanges record to the store
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///
		///</parameters>
		public virtual void SaveNew()
		{
			DAOWeatherRanges daoWeatherRanges = new DAOWeatherRanges();
			RegisterDataObject(daoWeatherRanges);
			BeginTransaction("savenewBOWeatherRanges");
			try
			{
				daoWeatherRanges.MinRange = _minRange;
				daoWeatherRanges.MaxRange = _maxRange;
				daoWeatherRanges.Adjective = _adjective;
				daoWeatherRanges.Insert();
				CommitTransaction();
				
				_id = daoWeatherRanges.Id;
				_minRange = daoWeatherRanges.MinRange;
				_maxRange = daoWeatherRanges.MaxRange;
				_adjective = daoWeatherRanges.Adjective;
				_isDirty = false;
			}
			catch
			{
				RollbackTransaction("savenewBOWeatherRanges");
				throw;
			}
		}
		
		///<Summary>
		///Update
		///This method updates one WeatherRanges record in the store
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///BOWeatherRanges
		///</parameters>
		public virtual void Update()
		{
			DAOWeatherRanges daoWeatherRanges = new DAOWeatherRanges();
			RegisterDataObject(daoWeatherRanges);
			BeginTransaction("updateBOWeatherRanges");
			try
			{
				daoWeatherRanges.Id = _id;
				daoWeatherRanges.MinRange = _minRange;
				daoWeatherRanges.MaxRange = _maxRange;
				daoWeatherRanges.Adjective = _adjective;
				daoWeatherRanges.Update();
				CommitTransaction();
				
				_id = daoWeatherRanges.Id;
				_minRange = daoWeatherRanges.MinRange;
				_maxRange = daoWeatherRanges.MaxRange;
				_adjective = daoWeatherRanges.Adjective;
				_isDirty = false;
			}
			catch
			{
				RollbackTransaction("updateBOWeatherRanges");
				throw;
			}
		}
		///<Summary>
		///Delete
		///This method deletes one WeatherRanges record from the store
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///
		///</parameters>
		public virtual void Delete()
		{
			DAOWeatherRanges daoWeatherRanges = new DAOWeatherRanges();
			RegisterDataObject(daoWeatherRanges);
			BeginTransaction("deleteBOWeatherRanges");
			try
			{
				daoWeatherRanges.Id = _id;
				daoWeatherRanges.Delete();
				CommitTransaction();
			}
			catch
			{
				RollbackTransaction("deleteBOWeatherRanges");
				throw;
			}
		}
		
		///<Summary>
		///WeatherRangesCollection
		///This method returns the collection of BOWeatherRanges objects
		///</Summary>
		///<returns>
		///List[BOWeatherRanges]
		///</returns>
		///<parameters>
		///
		///</parameters>
		public static IList<BOWeatherRanges> WeatherRangesCollection()
		{
			try
			{
				IList<BOWeatherRanges> boWeatherRangesCollection = new List<BOWeatherRanges>();
				IList<DAOWeatherRanges> daoWeatherRangesCollection = DAOWeatherRanges.SelectAll();
			
				foreach(DAOWeatherRanges daoWeatherRanges in daoWeatherRangesCollection)
					boWeatherRangesCollection.Add(new BOWeatherRanges(daoWeatherRanges));
			
				return boWeatherRangesCollection;
			}
			catch
			{
				throw;
			}
		}
		
		
		///<Summary>
		///WeatherRangesCollectionCount
		///This method returns the collection count of BOWeatherRanges objects
		///</Summary>
		///<returns>
		///Int32
		///</returns>
		///<parameters>
		///
		///</parameters>
		public static Int32 WeatherRangesCollectionCount()
		{
			try
			{
				Int32 objCount = DAOWeatherRanges.SelectAllCount();
				return objCount;
			}
			catch
			{
				throw;
			}
		}
		
		
		///<Summary>
		///Projections
		///This method returns the collection of projections, ordered and filtered by optional criteria
		///</Summary>
		///<returns>
		///List<BOWeatherRanges>
		///</returns>
		///<parameters>
		///ICriteria icriteria
		///</parameters>
		public virtual IDictionary<string, IList<object>> Projections(object o)
		{
			try
			{
				ICriteria icriteria = (ICriteria)o;
				IList<IDataProjection> lstDataProjection = (icriteria == null) ? null : icriteria.ListDataProjection();
				IList<IDataCriterion> lstDataCriteria = (icriteria == null) ? null : icriteria.ListDataCriteria();
				IList<IDataOrderBy> lstDataOrder = (icriteria == null) ? null : icriteria.ListDataOrder();
				IDataTake dataTake = (icriteria == null) ? null : icriteria.DataTake();
				IDataSkip dataSkip = (icriteria == null) ? null : icriteria.DataSkip();
				IDictionary<string, IList<object>> retObj = DAOWeatherRanges.SelectAllByCriteriaProjection(lstDataProjection, lstDataCriteria, lstDataOrder, dataSkip, dataTake);
				return retObj;
			}
			catch
			{
				throw;
			}
		}
		
		
		///<Summary>
		///WeatherRangesCollection<T>
		///This method implements the IQueryable Collection<T> method, returning a collection of BOWeatherRanges objects, filtered by optional criteria
		///</Summary>
		///<returns>
		///IList<T>
		///</returns>
		///<parameters>
		///object o
		///</parameters>
		public virtual IList<T> Collection<T>(object o)
		{
			try
			{
				ICriteria icriteria = (ICriteria)o;
				IList<T> boWeatherRangesCollection = new List<T>();
				IList<IDataCriterion> lstDataCriteria = (icriteria == null) ? null : icriteria.ListDataCriteria();
				IList<IDataOrderBy> lstDataOrder = (icriteria == null) ? null : icriteria.ListDataOrder();
				IDataTake dataTake = (icriteria == null) ? null : icriteria.DataTake();
				IDataSkip dataSkip = (icriteria == null) ? null : icriteria.DataSkip();
				IList<DAOWeatherRanges> daoWeatherRangesCollection = DAOWeatherRanges.SelectAllByCriteria(lstDataCriteria, lstDataOrder, dataSkip, dataTake);
			
				foreach(DAOWeatherRanges resdaoWeatherRanges in daoWeatherRangesCollection)
					boWeatherRangesCollection.Add((T)(object)new BOWeatherRanges(resdaoWeatherRanges));
			
				return boWeatherRangesCollection;
			}
			catch
			{
				throw;
			}
		}
		
		
		///<Summary>
		///WeatherRangesCollectionCount
		///This method implements the IQueryable CollectionCount method, returning a collection count of BOWeatherRanges objects, filtered by optional criteria
		///</Summary>
		///<returns>
		///Int32
		///</returns>
		///<parameters>
		///object o
		///</parameters>
		public virtual Int32 CollectionCount(object o)
		{
			try
			{
				ICriteria icriteria = (ICriteria)o;
				IList<IDataCriterion> lstDataCriteria = (icriteria == null) ? null : icriteria.ListDataCriteria();
				Int32 objCount = DAOWeatherRanges.SelectAllByCriteriaCount(lstDataCriteria);
				return objCount;
			}
			catch
			{
				throw;
			}
		}
		
		#endregion

		#region member properties
		
		public virtual Int64? Id
		{
			get
			{
				 return _id;
			}
			set
			{
				_id = value;
				_isDirty = true;
			}
		}
		
		public virtual Int32? MinRange
		{
			get
			{
				 return _minRange;
			}
			set
			{
				_minRange = value;
				_isDirty = true;
			}
		}
		
		public virtual Int32? MaxRange
		{
			get
			{
				 return _maxRange;
			}
			set
			{
				_maxRange = value;
				_isDirty = true;
			}
		}
		
		public virtual string Adjective
		{
			get
			{
				 return _adjective;
			}
			set
			{
				_adjective = value;
				_isDirty = true;
			}
		}
		
		public virtual object Repository
		{
			get {	return null;	}
			set	{	}
		}
		
		public virtual bool IsDirty
		{
			get
			{
				 return _isDirty;
			}
			set
			{
				_isDirty = value;
			}
		}
		#endregion
	}
}
