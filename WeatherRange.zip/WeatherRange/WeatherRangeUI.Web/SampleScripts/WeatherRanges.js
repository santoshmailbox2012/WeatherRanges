
var uri = 'api/weatherranges';

$(document).ready(function() {
    $("#edit").hide();
    getlist(0);
});

function getlist(page)
{
    // Send an AJAX request
    $.getJSON(getBaseUrl() + uri + "/?page=" + page)
        .done(function(data) {
            // On success, 'data' contains a list of mytestclass1.
            $.each(data.Data, function(key, item) {
                // Add a list item for the product.
                $('#listbody').html($('#listbody').html() + formatItem(item));
            });

            $(".pagination").html("");
            var style = 'normal';
            var numSteps = 5;
            var startPos = (data.Paging.CurrentPage - numSteps < 0 ? 0 : data.Paging.CurrentPage - numSteps);
            var endPos = (data.Paging.CurrentPage + numSteps > (data.Paging.PageCount) ? data.Paging.PageCount : data.Paging.CurrentPage + numSteps);
            if (startPos !== 0) $(".pagination").html(getpagelink(0, "&lt;&lt;", style));

            for (var i = startPos; i < endPos; i++)
            {
                var pageNum = i + 1;
                if (i === data.Paging.CurrentPage) style = 'active'; else style = 'normal';
                $(".pagination").html($(".pagination").html() + getpagelink(i, pageNum, style));
            }
            if (endPos !== data.Paging.PageCount) $(".pagination").html($(".pagination").html() + getpagelink(data.Paging.PageCount - 1, "&gt;&gt;", 'normal'));

        })
        .error(function (err) {
            error("An error occurred while getting items. " + err.responseText);
        });
}

function getpagelink(i, txt, style)
{
    return "<li " + (style==='active' ? "class='active'" : "") + "><a href = '#' onclick='clearlist(); getlist(" + i + ")'>" + txt + "</a></li>";
}



function geteditdetails(id) {
    $('#errorPanel').hide();
    $.getJSON(window.getBaseUrl() + uri + "/" + id)
        .done(function(data) {
            // On success, 'data' contains an item mytestclass1.
            $("#hiddenid").val(0);
            for (var i = 0; i < colnames.length; i++)
                $("#" + colnames[i]).val(data[colnames[i]]);
    })
    .error(function (err) {
            error("An error occurred while getting item details. " + err.responseText);
        });
}

function updateitem() {
    $('#errorPanel').hide();
    if ($('#MinRange').val.length == 0 || $('#MinRange').val.length == 0 || $('#Adjective').val.length == 0)
        return false;
        

    $.ajax({
        type: 'Put',
        url: window.getBaseUrl() + uri + "/" + $('#Id').val(),
        data: getformvalues(),
        dataType: "json"
    })
   .done(function ()
        {
            clearlist();
            getlist(0);
            $("#list").show();
            $("#edit").hide();
        })
        .error(function (err)
        {
            error("An error occurred while updating item. " + err.responseText);
        });
}

function addnewitem() {
    $('#errorPanel').hide();
    $.ajax({
        type: 'Post',
        url: window.getBaseUrl() + uri,
        data: getformvalues(),
        dataType: "json"
    })
    .done(function ()
    {
        clearlist();
        getlist(0);
        $("#list").show();
        $("#edit").hide();
    })
    .error(function (err)
    {
        error("An error occurred while adding item. " + err.responseText);
    });
}

function deleteitem(id){
    $('#errorPanel').hide();
    $.ajax({
            type: 'Delete',
            url: window.getBaseUrl() + uri + '/' + id
        })
        .done(function() 
        { 
            clearlist(); 
            getlist(0); 
        })
        .error(function (err) {
            error("An error occurred while deleting item. " + err.responseText);
        });
}


function clearlist()
{
    $('#listbody').html("");
}

function formatItem(item) {
    var row = "<tr>";
    for (var i = 0; i < colnames.length; i++)
    {
        row += "<td>" + item[colnames[i]] + "</td>";
    }
    row += "<td><a href='#' onclick='showedit(\"" + item.Id + "\", false)'>edit</a>";
    row += "&nbsp;<a href='#' onclick='confirmdelete(\"" + item.Id + "\")'>delete</a></td>";
    row += "</tr>";
    return row;
}

function error(errmsg) {
    $('#errorPanel').html(errmsg);
    $('#errorPanel').show();
}



function showedit(id, isnew) {
    $('#errorPanel').hide();
    $("#list").hide();
    $("#edit").show();
    clearedit();

    if (isnew)
    {
        $("#Id").removeAttr('readonly');
        $("#formcaption").html("Add new item");
        $("#hiddenid").val(-1);
        $("#updatebtn").html("Add");
    }
    else {
        $("#Id").attr('readonly');
        $("#formcaption").html("Edit item");
        $("#updatebtn").html("Update");
        geteditdetails(id);
    }
}

function canceledit()
{
    $('#errorPanel').hide();
    $("#list").show();
    $("#edit").hide();
}

function clearedit()
{
    $("#hiddenid").val(-1);
    for (var i = 0; i < colnames.length; i++)
        $("#" + colnames[i]).val("");
}

function update()
{
    if ($("#hiddenid").val() === "-1")
        addnewitem();
    else
        updateitem();
}

function confirmdelete(id)
{
    if (confirm("Are you sure you want to delete this item?"))
        deleteitem(id);
}

function getformvalues()
{
    var data = {};
    $("#editDetailForm").serializeArray().map(function(x) { data[x.name] = x.value; });
    return JSON.parse(JSON.stringify(data));
}


var colnames = [
	 "Id"
	, "MinRange"
	, "MaxRange"
	, "Adjective"
];
