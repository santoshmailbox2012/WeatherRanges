
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using WeatherRangeUI.DataObjects.Interfaces;

namespace WeatherRangeUI.DataObjects
{
	public partial class DAOWeatherRanges : WeatherRangeDBConnection_BaseData
	{
		#region member variables
		protected Int64? _id;
		protected Int32? _minRange;
		protected Int32? _maxRange;
		protected string _adjective;
		#endregion

		#region class methods
		public DAOWeatherRanges()
		{
		}
		///<Summary>
		///Select one row by primary key(s)
		///This method returns one row from the table TblWeatherRanges based on the primary key(s)
		///</Summary>
		///<returns>
		///DAOWeatherRanges
		///</returns>
		///<parameters>
		///Int64? id
		///</parameters>
		public static DAOWeatherRanges SelectOne(Int64? id)
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = InlineProcs.ctprTblWeatherRanges_SelectOne;
			command.CommandType = CommandType.Text;
			SqlConnection staticConnection = StaticSqlConnection;
			command.Connection = staticConnection;

			DataTable dt = new DataTable("TblWeatherRanges");
			SqlDataAdapter sqlAdapter = new SqlDataAdapter(command);
			try
			{
				command.Parameters.Add(CtSqlParameter.Get("@ID", SqlDbType.BigInt, 8, ParameterDirection.Input, false, 19, 0, "", DataRowVersion.Proposed, (object)id?? (object)DBNull.Value));

				staticConnection.Open();
				sqlAdapter.Fill(dt);

				DAOWeatherRanges retObj = null;
				if(dt.Rows.Count > 0)
				{
					retObj = new DAOWeatherRanges();
					retObj._id					 = Convert.IsDBNull(dt.Rows[0]["ID"]) ? (Int64?)null : (Int64?)dt.Rows[0]["ID"];
					retObj._minRange					 = Convert.IsDBNull(dt.Rows[0]["MinRange"]) ? (Int32?)null : (Int32?)dt.Rows[0]["MinRange"];
					retObj._maxRange					 = Convert.IsDBNull(dt.Rows[0]["MaxRange"]) ? (Int32?)null : (Int32?)dt.Rows[0]["MaxRange"];
					retObj._adjective					 = Convert.IsDBNull(dt.Rows[0]["Adjective"]) ? null : (string)dt.Rows[0]["Adjective"];
				}
				return retObj;
			}
			catch
			{
				throw;
			}
			finally
			{
				staticConnection.Close();
				command.Dispose();
			}
		}

		///<Summary>
		///Delete one row by primary key(s)
		///this method allows the object to delete itself from the table TblWeatherRanges based on its primary key
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///
		///</parameters>
		public virtual void Delete()
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = InlineProcs.ctprTblWeatherRanges_DeleteOne;
			command.CommandType = CommandType.Text;
			command.Connection = _connectionProvider.Connection;
			command.Transaction = _connectionProvider.CurrentTransaction;

			try
			{
				command.Parameters.Add(CtSqlParameter.Get("@ID", SqlDbType.BigInt, 8, ParameterDirection.Input, false, 19, 0, "", DataRowVersion.Proposed, (object)_id?? (object)DBNull.Value));

				command.ExecuteNonQuery();

			}
			catch
			{
				throw;
			}
			finally
			{
				command.Dispose();
			}
		}

		///<Summary>
		///Insert a new row
		///This method saves a new object to the table TblWeatherRanges
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///
		///</parameters>
		public virtual void Insert()
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = InlineProcs.ctprTblWeatherRanges_InsertOne;
			command.CommandType = CommandType.Text;
			command.Connection = _connectionProvider.Connection;
			command.Transaction = _connectionProvider.CurrentTransaction;

			try
			{
				command.Parameters.Add(CtSqlParameter.Get("@ID", SqlDbType.BigInt, 8, ParameterDirection.Output, false, 19, 0, "", DataRowVersion.Proposed, _id));
				command.Parameters.Add(CtSqlParameter.Get("@MinRange", SqlDbType.Int, 4, ParameterDirection.InputOutput, true, 10, 0, "", DataRowVersion.Proposed, (object)_minRange?? (object)DBNull.Value));
				command.Parameters.Add(CtSqlParameter.Get("@MaxRange", SqlDbType.Int, 4, ParameterDirection.InputOutput, true, 10, 0, "", DataRowVersion.Proposed, (object)_maxRange?? (object)DBNull.Value));
				command.Parameters.Add(CtSqlParameter.Get("@Adjective", SqlDbType.VarChar, 50, ParameterDirection.InputOutput, true, 0, 0, "", DataRowVersion.Proposed, (object)_adjective?? (object)DBNull.Value));

				command.ExecuteNonQuery();

				_id					 = Convert.IsDBNull(command.Parameters["@ID"].Value) ? (Int64?)null : (Int64?)command.Parameters["@ID"].Value;
				_minRange					 = Convert.IsDBNull(command.Parameters["@MinRange"].Value) ? (Int32?)null : (Int32?)command.Parameters["@MinRange"].Value;
				_maxRange					 = Convert.IsDBNull(command.Parameters["@MaxRange"].Value) ? (Int32?)null : (Int32?)command.Parameters["@MaxRange"].Value;
				_adjective					 = Convert.IsDBNull(command.Parameters["@Adjective"].Value) ? null : (string)command.Parameters["@Adjective"].Value;

			}
			catch
			{
				throw;
			}
			finally
			{
				command.Dispose();
			}
		}

		///<Summary>
		///Select all rows
		///This method returns all data rows in the table TblWeatherRanges
		///</Summary>
		///<returns>
		///IList-DAOWeatherRanges.
		///</returns>
		///<parameters>
		///
		///</parameters>
		public static IList<DAOWeatherRanges> SelectAll()
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = InlineProcs.ctprTblWeatherRanges_SelectAll;
			command.CommandType = CommandType.Text;
			SqlConnection staticConnection = StaticSqlConnection;
			command.Connection = staticConnection;

			DataTable dt = new DataTable("TblWeatherRanges");
			SqlDataAdapter sqlAdapter = new SqlDataAdapter(command);
			try
			{

				staticConnection.Open();
				sqlAdapter.Fill(dt);

				List<DAOWeatherRanges> objList = new List<DAOWeatherRanges>();
				if(dt.Rows.Count > 0)
				{
					foreach(DataRow row in dt.Rows)
					{
						DAOWeatherRanges retObj = new DAOWeatherRanges();
						retObj._id					 = Convert.IsDBNull(row["ID"]) ? (Int64?)null : (Int64?)row["ID"];
						retObj._minRange					 = Convert.IsDBNull(row["MinRange"]) ? (Int32?)null : (Int32?)row["MinRange"];
						retObj._maxRange					 = Convert.IsDBNull(row["MaxRange"]) ? (Int32?)null : (Int32?)row["MaxRange"];
						retObj._adjective					 = Convert.IsDBNull(row["Adjective"]) ? null : (string)row["Adjective"];
						objList.Add(retObj);
					}
				}
				return objList;
			}
			catch
			{
				throw;
			}
			finally
			{
				staticConnection.Close();
				command.Dispose();
			}
		}

		///<Summary>
		///</Summary>
		///<returns>
		///Int32
		///</returns>
		///<parameters>
		///
		///</parameters>
		public static Int32 SelectAllCount()
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = InlineProcs.ctprTblWeatherRanges_SelectAllCount;
			command.CommandType = CommandType.Text;
			SqlConnection staticConnection = StaticSqlConnection;
			command.Connection = staticConnection;

			try
			{

				staticConnection.Open();
				Int32 retCount = (Int32)command.ExecuteScalar();

				return retCount;
			}
			catch
			{
				throw;
			}
			finally
			{
				staticConnection.Close();
				command.Dispose();
			}
		}

		///<Summary>
		///Select specific fields of all rows using criteriaquery api
		///This method returns specific fields of all data rows in the table using criteriaquery apiTblWeatherRanges
		///</Summary>
		///<returns>
		///IDictionary-string, IList-object..
		///</returns>
		///<parameters>
		///IList<IDataProjection> listProjection, IList<IDataCriterion> listCriterion, IList<IDataOrderBy> listOrder, IDataSkip dataSkip, IDataTake dataTake
		///</parameters>
		public static IDictionary<string, IList<object>> SelectAllByCriteriaProjection(IList<IDataProjection> listProjection, IList<IDataCriterion> listCriterion, IList<IDataOrderBy> listOrder, IDataSkip dataSkip, IDataTake dataTake)
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = GetSelectionCriteria(InlineProcs.ctprTblWeatherRanges_SelectAllByCriteriaProjection, listProjection, listCriterion, listOrder, dataSkip, dataTake);
			command.CommandType = CommandType.Text;
			SqlConnection staticConnection = StaticSqlConnection;
			command.Connection = staticConnection;

			DataTable dt = new DataTable("TblWeatherRanges");
			SqlDataAdapter sqlAdapter = new SqlDataAdapter(command);
			try
			{

				staticConnection.Open();
				sqlAdapter.Fill(dt);

				IDictionary<string, IList<object>> dict = new Dictionary<string, IList<object>>();
				foreach (IDataProjection projection in listProjection)
				{
					IList<object> lst = new List<object>();
					dict.Add(projection.Member, lst);
					foreach (DataRow row in dt.Rows)
					{
						if (string.Compare(projection.Member, "ID", true) == 0) lst.Add(Convert.IsDBNull(row["ID"]) ? (Int64?)null : (Int64?)row["ID"]);
						if (string.Compare(projection.Member, "MinRange", true) == 0) lst.Add(Convert.IsDBNull(row["MinRange"]) ? (Int32?)null : (Int32?)row["MinRange"]);
						if (string.Compare(projection.Member, "MaxRange", true) == 0) lst.Add(Convert.IsDBNull(row["MaxRange"]) ? (Int32?)null : (Int32?)row["MaxRange"]);
						if (string.Compare(projection.Member, "Adjective", true) == 0) lst.Add(Convert.IsDBNull(row["Adjective"]) ? null : (string)row["Adjective"]);
					}
				}
				return dict;
			}
			catch
			{
				throw;
			}
			finally
			{
				staticConnection.Close();
				command.Dispose();
			}
		}

		///<Summary>
		///Select all rows by filter criteria
		///This method returns all data rows in the table using criteriaquery api TblWeatherRanges
		///</Summary>
		///<returns>
		///IList-DAOWeatherRanges.
		///</returns>
		///<parameters>
		///IList<IDataCriterion> listCriterion, IList<IDataOrderBy> listOrder, IDataSkip dataSkip, IDataTake dataTake
		///</parameters>
		public static IList<DAOWeatherRanges> SelectAllByCriteria(IList<IDataCriterion> listCriterion, IList<IDataOrderBy> listOrder, IDataSkip dataSkip, IDataTake dataTake)
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = GetSelectionCriteria(InlineProcs.ctprTblWeatherRanges_SelectAllByCriteria, null, listCriterion, listOrder, dataSkip, dataTake);
			command.CommandType = CommandType.Text;
			SqlConnection staticConnection = StaticSqlConnection;
			command.Connection = staticConnection;

			DataTable dt = new DataTable("TblWeatherRanges");
			SqlDataAdapter sqlAdapter = new SqlDataAdapter(command);
			try
			{

				staticConnection.Open();
				sqlAdapter.Fill(dt);

				List<DAOWeatherRanges> objList = new List<DAOWeatherRanges>();
				if(dt.Rows.Count > 0)
				{
					foreach(DataRow row in dt.Rows)
					{
						DAOWeatherRanges retObj = new DAOWeatherRanges();
						retObj._id					 = Convert.IsDBNull(row["ID"]) ? (Int64?)null : (Int64?)row["ID"];
						retObj._minRange					 = Convert.IsDBNull(row["MinRange"]) ? (Int32?)null : (Int32?)row["MinRange"];
						retObj._maxRange					 = Convert.IsDBNull(row["MaxRange"]) ? (Int32?)null : (Int32?)row["MaxRange"];
						retObj._adjective					 = Convert.IsDBNull(row["Adjective"]) ? null : (string)row["Adjective"];
						objList.Add(retObj);
					}
				}
				return objList;
			}
			catch
			{
				throw;
			}
			finally
			{
				staticConnection.Close();
				command.Dispose();
			}
		}

		///<Summary>
		///Select count of all rows using criteriaquery api
		///This method returns all data rows in the table using criteriaquery api TblWeatherRanges
		///</Summary>
		///<returns>
		///Int32
		///</returns>
		///<parameters>
		///IList<IDataCriterion> listCriterion
		///</parameters>
		public static Int32 SelectAllByCriteriaCount(IList<IDataCriterion> listCriterion)
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = GetSelectionCriteria(InlineProcs.ctprTblWeatherRanges_SelectAllByCriteriaCount, null, listCriterion, null);
			command.CommandType = CommandType.Text;
			SqlConnection staticConnection = StaticSqlConnection;
			command.Connection = staticConnection;

			try
			{

				staticConnection.Open();
				Int32 retCount = (Int32)command.ExecuteScalar();

				return retCount;
			}
			catch
			{
				throw;
			}
			finally
			{
				staticConnection.Close();
				command.Dispose();
			}
		}

		///<Summary>
		///Update one row by primary key(s)
		///This method allows the object to update itself in the table TblWeatherRanges based on its primary key(s)
		///</Summary>
		///<returns>
		///void
		///</returns>
		///<parameters>
		///
		///</parameters>
		public virtual void Update()
		{
			SqlCommand	command = new SqlCommand();
			command.CommandText = InlineProcs.ctprTblWeatherRanges_UpdateOne;
			command.CommandType = CommandType.Text;
			command.Connection = _connectionProvider.Connection;
			command.Transaction = _connectionProvider.CurrentTransaction;

			try
			{
				command.Parameters.Add(CtSqlParameter.Get("@ID", SqlDbType.BigInt, 8, ParameterDirection.InputOutput, false, 19, 0, "", DataRowVersion.Proposed, (object)_id?? (object)DBNull.Value));
				command.Parameters.Add(CtSqlParameter.Get("@MinRange", SqlDbType.Int, 4, ParameterDirection.InputOutput, true, 10, 0, "", DataRowVersion.Proposed, (object)_minRange?? (object)DBNull.Value));
				command.Parameters.Add(CtSqlParameter.Get("@MaxRange", SqlDbType.Int, 4, ParameterDirection.InputOutput, true, 10, 0, "", DataRowVersion.Proposed, (object)_maxRange?? (object)DBNull.Value));
				command.Parameters.Add(CtSqlParameter.Get("@Adjective", SqlDbType.VarChar, 50, ParameterDirection.InputOutput, true, 0, 0, "", DataRowVersion.Proposed, (object)_adjective?? (object)DBNull.Value));

				command.ExecuteNonQuery();

				_id					 = Convert.IsDBNull(command.Parameters["@ID"].Value) ? (Int64?)null : (Int64?)command.Parameters["@ID"].Value;
				_minRange					 = Convert.IsDBNull(command.Parameters["@MinRange"].Value) ? (Int32?)null : (Int32?)command.Parameters["@MinRange"].Value;
				_maxRange					 = Convert.IsDBNull(command.Parameters["@MaxRange"].Value) ? (Int32?)null : (Int32?)command.Parameters["@MaxRange"].Value;
				_adjective					 = Convert.IsDBNull(command.Parameters["@Adjective"].Value) ? null : (string)command.Parameters["@Adjective"].Value;

			}
			catch
			{
				throw;
			}
			finally
			{
				command.Dispose();
			}
		}

		#endregion

		#region member properties

		public Int64? Id
		{
			get
			{
				return _id;
			}
			set
			{
				_id = value;
			}
		}

		public Int32? MinRange
		{
			get
			{
				return _minRange;
			}
			set
			{
				_minRange = value;
			}
		}

		public Int32? MaxRange
		{
			get
			{
				return _maxRange;
			}
			set
			{
				_maxRange = value;
			}
		}

		public string Adjective
		{
			get
			{
				return _adjective;
			}
			set
			{
				_adjective = value;
			}
		}

		#endregion
	}
}

#region inline sql procs
namespace WeatherRangeUI.DataObjects
{
	public partial class InlineProcs
	{
		internal static string ctprTblWeatherRanges_SelectOne = @"
			-- Select one row based on the primary key(s)
			-- selects all rows from the table
			SELECT 
			[ID]
			,[MinRange]
			,[MaxRange]
			,[Adjective]
			FROM [dbo].[TblWeatherRanges]
			WHERE 
			[ID] = @ID
			";

		internal static string ctprTblWeatherRanges_DeleteOne = @"
			-- Delete a row based on the primary key(s)
			-- delete all matching from the table
			DELETE [dbo].[TblWeatherRanges]
			WHERE 
			[ID] = @ID
			";

		internal static string ctprTblWeatherRanges_InsertOne = @"
			-- Insert a new row
			-- inserts a new row into the table
			INSERT [dbo].[TblWeatherRanges]
			(
			[MinRange]
			,[MaxRange]
			,[Adjective]
			)
			VALUES
			(
			@MinRange
			,@MaxRange
			,@Adjective
			)
			SELECT 
			@ID = [ID]
			,@MinRange = [MinRange]
			,@MaxRange = [MaxRange]
			,@Adjective = [Adjective]
			FROM [dbo].[TblWeatherRanges]
			WHERE 
			[ID] = SCOPE_IDENTITY()
			";

		internal static string ctprTblWeatherRanges_SelectAll = @"
			-- Select All rows
			-- selects all rows from the table
			SELECT 
			[ID]
			,[MinRange]
			,[MaxRange]
			,[Adjective]
			FROM [dbo].[TblWeatherRanges]
			";

		internal static string ctprTblWeatherRanges_SelectAllCount = @"
			
			-- selects count of all rows from the table
			SELECT COUNT(*)
			FROM [dbo].[TblWeatherRanges]
			";

		internal static string ctprTblWeatherRanges_SelectAllByCriteriaProjection = @"
			
			-- selects all rows from the table by criteria
			SELECT 
			##STARTFIELDS##
			##ENDFIELDS##
			FROM [dbo].[TblWeatherRanges]
			##CRITERIA##
			";

		internal static string ctprTblWeatherRanges_SelectAllByCriteria = @"
			
			-- selects all rows from the table by criteria
			SELECT 
			[ID]
			,[MinRange]
			,[MaxRange]
			,[Adjective]
			FROM [dbo].[TblWeatherRanges]
			##CRITERIA##
			";

		internal static string ctprTblWeatherRanges_SelectAllByCriteriaCount = @"
			
			-- selects count of all rows from the table according to criteria
			SELECT COUNT(*)
			FROM [dbo].[TblWeatherRanges]
			##CRITERIA##
			";

		internal static string ctprTblWeatherRanges_UpdateOne = @"
			-- Update one row based on the primary key(s)
			-- updates a row in the table based on the primary key
			
			UPDATE [dbo].[TblWeatherRanges]
			SET
			[MinRange] = @MinRange
			,[MaxRange] = @MaxRange
			,[Adjective] = @Adjective
			WHERE 
			[ID] = @ID
			SELECT 
			@ID = [ID]
			,@MinRange = [MinRange]
			,@MaxRange = [MaxRange]
			,@Adjective = [Adjective]
			FROM [dbo].[TblWeatherRanges]
			WHERE 
			[ID] = @ID
			";

	}
}
#endregion
