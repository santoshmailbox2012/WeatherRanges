using System.Threading.Tasks;

namespace WeatherRangeUI.Web.Services
{
    public interface IEmailSender
    {
        Task SendEmailAsync(string email, string subject, string message);
    }
}
