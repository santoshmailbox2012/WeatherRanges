 
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WeatherRangeUI.Web.SampleViewModels;
using WeatherRangeUI.BusinessObjects;
using WeatherRangeUI.BusinessObjects.Interfaces;

namespace WeatherRangeUI.Web.SampleApiControllers
{
	[Route("api/weatherranges")]
	[ResponseCache(CacheProfileName = "NoCache")]
	public partial class WeatherRangesController : ControllerBase
	{

        // GET: api/WeatherRanges
        [HttpGet]
        [ProducesResponseType(200, Type = typeof(IList<WeatherRangesVm>))]
        public async Task<IActionResult> GetWeatherRanges(int page = 0, int pageSize = 5)
        {
            int totalCount = 0;

            IList<WeatherRangesVm> listVm = new List<WeatherRangesVm>();
            var result = Task.Factory.StartNew(() => {

                ICriteria criteria = new Criteria<BOWeatherRanges>();
                totalCount = criteria.Count();

                IList<BOWeatherRanges> listBOs = criteria
                    .Add(new OrderBy("ID", OrderBy.OrderDirection.Ascending))
                    .Skip(page * pageSize)
                    .Take(pageSize)
                    .List<BOWeatherRanges>();

                foreach (var bo in listBOs)
                    listVm.Add(new WeatherRangesVm(bo));
                return listVm;
            });
            await result;

            return Ok(new { Data = result.Result, Paging = new { Total = totalCount, Limit = pageSize, CurrentPage = page, PageCount = (int) Math.Ceiling((double)totalCount / pageSize) } });
        }

        // GET: api/WeatherRanges/5
        [HttpGet("{id}")]
        [ProducesResponseType(200, Type = typeof(WeatherRangesVm))]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetWeatherRanges(Int64 id)
        {
            var result = Task.Factory.StartNew(() => {

                BOWeatherRanges bo = new Criteria<BOWeatherRanges>()
                .Add(Expression.Eq("ID", id))
                .SingleOrDefault<BOWeatherRanges>();
                return bo == null ? null : new WeatherRangesVm(bo);

            });
            await result;
            if (result.Result == null)
                return NotFound("The item with Id: " + id + " was not found");

            return Ok(result.Result);
        }

        // PUT: api/WeatherRanges/5
        [HttpPut("{id}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(500)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> PutWeatherRanges(Int64 id, WeatherRangesVm vm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != vm.Id)
            {
                return BadRequest();
            }
            
            string err = null;
            var result = Task.Factory.StartNew(() => {

                IUnitOfWork uow = new UnitOfWorkImp(); 
                var bo = vm.BOWeatherRanges();
                uow.Update(bo);
                return uow.Commit(out err);
            });
            await result;
            if (!result.Result)
                return StatusCode((int)HttpStatusCode.InternalServerError, err);

            return Ok(true);
        }

        // POST: api/WeatherRanges
        [HttpPost]
        [ProducesResponseType(201, Type = typeof(WeatherRangesVm))]
        [ProducesResponseType(500)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> PostWeatherRanges(WeatherRangesVm vm)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string err = null;
            var result = Task.Factory.StartNew(() =>
            {
                IUnitOfWork uow = new UnitOfWorkImp(); 
                var bo = vm.BOWeatherRanges();
                uow.Create(bo);

                if (uow.Commit(out err))
                {
                    vm = new WeatherRangesVm(bo);
                    return true;
                }
                return false;
                
            });
            await result;
            if(!result.Result)
                return StatusCode((int)HttpStatusCode.InternalServerError, err);

            return CreatedAtRoute("defaultApi", new { id = vm.Id }, vm);
        }

        // DELETE: api/WeatherRanges/5
        [HttpDelete("{id}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(500)]
        public async Task<IActionResult> DeleteWeatherRanges(Int64 id)
        {
            string err = null;
            var result = Task.Factory.StartNew(() =>
            {
                 IUnitOfWork uow = new UnitOfWorkImp(); 
                var bo = new BOWeatherRanges(id);
                
                
                uow.Delete(bo);

                return uow.Commit(out err);
            });

            await result;
            if (!result.Result)
                return StatusCode((int)HttpStatusCode.InternalServerError, err);

            return NoContent();
        }

        
	}
}
